package com.exam.util;

/**
 * 常量数据
 *
 */
public class Constant {

	/**
	 * 成功
	 */
	public static final int SUCCESS_CODE = 0;
	public static final String SUCCESS_MSG = "成功";
	/**
	 * 失败
	 */
	public static final int FAILED_CODE = 1;
	public static final String FAILED_MSG = "失败";
	
}
